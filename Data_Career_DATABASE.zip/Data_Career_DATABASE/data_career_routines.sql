-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: 127.0.0.1    Database: data_career
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `scientist_skill_count`
--

DROP TABLE IF EXISTS `scientist_skill_count`;
/*!50001 DROP VIEW IF EXISTS `scientist_skill_count`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `scientist_skill_count` AS SELECT 
 1 AS `skill_id`,
 1 AS `skill_name`,
 1 AS `count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `analyst_skill_count`
--

DROP TABLE IF EXISTS `analyst_skill_count`;
/*!50001 DROP VIEW IF EXISTS `analyst_skill_count`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `analyst_skill_count` AS SELECT 
 1 AS `skill_id`,
 1 AS `skill_name`,
 1 AS `count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `engineer_skill_count`
--

DROP TABLE IF EXISTS `engineer_skill_count`;
/*!50001 DROP VIEW IF EXISTS `engineer_skill_count`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `engineer_skill_count` AS SELECT 
 1 AS `skill_id`,
 1 AS `skill_name`,
 1 AS `count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `top_10_skills`
--

DROP TABLE IF EXISTS `top_10_skills`;
/*!50001 DROP VIEW IF EXISTS `top_10_skills`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `top_10_skills` AS SELECT 
 1 AS `skill_name`,
 1 AS `skill_id`,
 1 AS `skill_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `scientist_skill_count`
--

/*!50001 DROP VIEW IF EXISTS `scientist_skill_count`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `scientist_skill_count` AS select `a`.`skill_id` AS `skill_id`,`skills1`.`skill_name` AS `skill_name`,`a`.`count` AS `count` from ((select `c`.`skill_id` AS `skill_id`,count(0) AS `count` from (`connected` `c` join `job_title_1` `j` on((`c`.`job_title_id` = `j`.`job_title_id`))) where (`j`.`branch_id` = 4) group by `c`.`skill_id`) `a` left join `skills1` on((`skills1`.`skill_id` = `a`.`skill_id`))) order by `a`.`count` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `analyst_skill_count`
--

/*!50001 DROP VIEW IF EXISTS `analyst_skill_count`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `analyst_skill_count` AS select `a`.`skill_id` AS `skill_id`,`skills1`.`skill_name` AS `skill_name`,`a`.`count` AS `count` from ((select `c`.`skill_id` AS `skill_id`,count(0) AS `count` from (`connected` `c` join `job_title_1` `j` on((`c`.`job_title_id` = `j`.`job_title_id`))) where (`j`.`branch_id` = 0) group by `c`.`skill_id`) `a` left join `skills1` on((`skills1`.`skill_id` = `a`.`skill_id`))) order by `a`.`count` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `engineer_skill_count`
--

/*!50001 DROP VIEW IF EXISTS `engineer_skill_count`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `engineer_skill_count` AS select `a`.`skill_id` AS `skill_id`,`skills1`.`skill_name` AS `skill_name`,`a`.`count` AS `count` from ((select `c`.`skill_id` AS `skill_id`,count(0) AS `count` from (`connected` `c` join `job_title_1` `j` on((`c`.`job_title_id` = `j`.`job_title_id`))) where (`j`.`branch_id` = 1) group by `c`.`skill_id`) `a` left join `skills1` on((`skills1`.`skill_id` = `a`.`skill_id`))) order by `a`.`count` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `top_10_skills`
--

/*!50001 DROP VIEW IF EXISTS `top_10_skills`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `top_10_skills` AS select `s`.`skill_name` AS `skill_name`,`s`.`skill_id` AS `skill_id`,count(0) AS `skill_count` from (`connected` `c` join `skills1` `s` on((`s`.`skill_id` = `c`.`skill_id`))) group by `c`.`skill_id`,`s`.`skill_name` order by count(0) desc limit 12 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-03 12:45:44
